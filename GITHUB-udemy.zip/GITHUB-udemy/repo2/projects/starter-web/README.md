adding readme after stash 

modifying reading file for stashing
# Starter Web Repo

This repository is for showing how Git and GitHub work
Adding a line for rebasing example.
more changes from myfeature branches too

## Introduction

## Purpose

Sample website with plenty of files for demos

## How TO Contribute

please fork this repository and then issue Pull Requerst for review.
## Deployment


This is a simple modification in the test case fow showing how touse Git and Github tohether. 


This is an exmaple is to show different parts of the Git respostory and various commands usng a web project.


As stated above, the main purpose is to provide simple examples for Git Training Demos. A To Provide and Henced Form In the Regulation For The Very Close Enviornment And To Make The Deal For The Test Cases.
6th Edit for the readme file

## copyright
copyright notice 
